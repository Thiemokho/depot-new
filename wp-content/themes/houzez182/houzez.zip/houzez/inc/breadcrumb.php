<?php
$site_breadcrumb = houzez_option('site_breadcrumb');

if( $site_breadcrumb != 0 ) {
    houzez_breadcrumbs();
}
?>
